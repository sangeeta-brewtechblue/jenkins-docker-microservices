package com.sj;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.out.println(checkIfInputIsAnEvenNumber(122)); 
	}
	
	  public static boolean checkIfInputIsAnEvenNumber(int number){
	        return number % 2 == 0;
	    }

}
